
//#include "INCLUDE/support.h"
#include <time.h> 
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <thread>
#include <jni.h>
#include "oxorany.cpp"

int handle;
typedef int8_t BYTE;
int killGG();

	
typedef char PACKAGENAME;
long int get_module_base(int pid, const char *module_name)
{
	FILE *fp;
	long addr = 0;
	char *pch;
	char filename[32];
	char line[1024];
	snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
	fp = fopen(filename, "r");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			if (strstr(line, module_name))
			{
				pch = strtok(line, "-");
				addr = strtoul(pch, NULL, 16);
				break;
			}
		}
		fclose(fp);
	}
	return addr;
}


long int ReadValue(long int addr)
{
 long int var = 0;
 pread64(handle, &var, 8, addr);
 return var;
}

float WriteAddress_FLOAT(long int addr, float value) {
 pwrite64(handle, &value, 4, addr);
 return 0;
}

int SajadAli_FLOAT(long int addr, float value)
{
	pwrite64(handle, &value, 4, addr);
	return 0;
}

int SajadAli_DWORD(long int addr, int value)
{
	pwrite64(handle, &value, 4, addr);
	return 0;
}

int getPID(PACKAGENAME * PackageName)
{
	DIR *dir = NULL;
	struct dirent *ptr = NULL;
	FILE *fp = NULL;
	char filepath[256];
	char filetext[128];
	dir = opendir("/proc");
	if (NULL != dir)
	{
		while ((ptr = readdir(dir)) != NULL)
		{
			if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
				continue;
			if (ptr->d_type != DT_DIR)
				continue;
			sprintf(filepath, "/proc/%s/cmdline", ptr->d_name);
			fp = fopen(filepath, "r");
			if (NULL != fp)
			{
				fgets(filetext, sizeof(filetext), fp);
				if (strcmp(filetext, PackageName) == 0)
				{
					break;
				}
				fclose(fp);
			}
		}
	}
	if (readdir(dir) == NULL)
	{
		return 0;
	}
	closedir(dir);
	return atoi(ptr->d_name);
}

int EDIT_HEX(long int addr, BYTE* hex_value, int size)
{
    pwrite64(handle, hex_value, size, addr);
    return 0;
}

void edithex(long int address, char* hex_value) {
    int hex_len = strlen(hex_value) / 3 +1;
    BYTE* hex_bytes = (BYTE*)malloc(hex_len * sizeof(BYTE));
    for (int i = 0; i < hex_len; i++) {
        char byte_str[3] = {hex_value[i*3], hex_value[i*3+1], '\0'};
        hex_bytes[i] = strtol(byte_str, NULL, 16);
    }
   EDIT_HEX(address, hex_bytes, hex_len);
   BYTE* read_bytes = (BYTE*)malloc(hex_len * sizeof(BYTE));
    pread64(handle, read_bytes, hex_len, address);
    int is_equal = 1;
    for (int i = 0; i < hex_len; i++) {
        if (hex_bytes[i] != read_bytes[i]) {
            is_equal = 0;
            break;
        }
    }

    if (is_equal) {
        printf("Successfully wrote %d bytes to address 0x%lx\n", hex_len, address);
    } else {
        printf("Failed to write bytes to address 0x%lx\n", address);
    }

    free(hex_bytes);
    free(read_bytes);
}
FILE *file; 


	
int main(int argc, char **argv)
{
	
	killGG();
	
	
	int Features = atoi(argv[1]);
	{
		int ipid = getPID("com.tencent.ig");
		
		if (ipid == 0)
		{
			ipid = getPID("com.pubg.krmobile");
		
			if (ipid == 0)
			{
				ipid = getPID("com.rekoo.pubgm");
				
				if (ipid == 0)
				{
					ipid = getPID("com.vng.pubgmobile");
				
					if (ipid == 0)
					{
						ipid = getPID("com.pubg.imobile");
						
						if (ipid == 0)
						{
							puts("ғᴀɪʟᴇᴅ ᴛᴏ ɢᴇᴛ ᴍᴇᴍᴏʀʏ!");
							exit(1);
						}
					}
				}
			}
		}
		char lj[64];
		sprintf(lj, "/proc/%d/mem", ipid);
		handle = open(lj, O_RDWR);
		if (handle == -1)
		{
			puts("\n\n @@HUSEEN311\n\n @@HUSEEN311\n\n");
			exit(1);
		}
		char mname[] = "libUE4.so";
		char mname2[] = "libanogs.so";
		char mname3[] = "libgcloud.so";
		char mname4[] = "libhdmpve.so";
		char mname5[] = "libTDataMaster.so";
		long int libUE4 = get_module_base(ipid, mname);
		long int libanogs = get_module_base(ipid, mname2);
		long int libgcloud = get_module_base(ipid, mname3);
		long int libhdmp = get_module_base(ipid, mname4);		
		long int libTDataMaster = get_module_base(ipid, mname5);	
		switch (Features)
		{
		
		case 2009: //         gl kr 64 crashfixer. 0x67a9f0 new
		edithex(libanogs + oxorany(0x2E6E58), "FF 43 00 D1 E0 07 00 F9"); // fix crash
		edithex(libanogs + oxorany(0x2E6A68), "FF 83 00 D1 FD 7B 01 A9"); // fix crash
        edithex(libanogs + oxorany(0x2E69E8), "FF C3 00 D1 FD 7B 02 A9"); // اسبوع
        edithex(libanogs + oxorany(0x2E69D4), "FF 43 00 D1 E0 07 00 F9");// 10 دقايق
        edithex(libanogs + oxorany(0x2E6A40), "FF 83 00 D1 FD 7B 01 A9");// يوم
        edithex(libanogs + oxorany(0x2E7E60), "FF 43 05 D1 DC 9B 00 F9");// غيابي
        edithex(libanogs + oxorany(0x2E7F60), "FF 43 03 D1 FD 7B 0C A9"); // غيابي  مربوطات
        edithex(libanogs + oxorany(0x2E84D4), "FF 43 01 D1 FD 7B 04 A9"); // fix crash
		edithex(libanogs + oxorany(0x2E89AC), "FF 43 01 D1 FD 7B 04 A9"); // fix crash
        edithex(libanogs + oxorany(0x2F409C), "FF 43 00 D1 E0 07 00 F9"); // اسبوع
        edithex(libanogs + oxorany(0x2F4138), "FF C3 00 D1 08 00 80 12");// 10 دقايق
        edithex(libanogs + oxorany(0x2F4840), "FF 03 01 D1 FD 7B 03 A9");// يوم
        edithex(libanogs + oxorany(0x2F4BBC), "FF 43 01 D1 FD 7B 04 A9");// غيابي
        edithex(libanogs + oxorany(0x2F4CE0), "FF 43 01 D1 FD 7B 04 A9"); // غيابي  مربوطات
        edithex(libTDataMaster + oxorany(0x2CBB34), "FD 7B BD A9 FD 03 00 91"); // fix crash
		edithex(libTDataMaster + oxorany(0x2CB4CC), "FD 7B BC A9 FD 03 00 91"); // fix crash
        edithex(libTDataMaster + oxorany(0x2CB354), "FD 7B BD A9 FD 03 00 91"); // اسبوع
        edithex(libTDataMaster + oxorany(0x2CA160), "FD 7B BD A9 FD 03 00 91");// 10 دقايق
        edithex(libTDataMaster + oxorany(0x2C9E5C), "FD 7B BD A9 FD 03 00 91");// يوم
        edithex(libTDataMaster + oxorany(0x2C87B4), "FD 7B BA A9 FD 03 00 91");// غيابي
        edithex(libgcloud + oxorany(0x461154), "FD 7B BC A9 FD 03 00 91"); // غيابي  مربوطات
        edithex(libgcloud + oxorany(0x415B84), "FD 7B BA A9 E6 03 00 AA"); // غيابي  مربوطات
        edithex(libgcloud + oxorany(0x416340), "00 14 00 B0 01 20 2B 91"); // غيابي  مربوطات
        edithex(libgcloud + oxorany(0x4165D8), "FD 7B BE A9 E4 03 00 AA"); // غيابي  مربوطات
        edithex(libgcloud + oxorany(0x416658), "FD 7B BC A9 E3 03 23 AA"); // غيابي  مربوطات
        edithex(libgcloud + oxorany(0x416764), "FD 7B BC A9 FD 03 00 91"); // غيابي  مربوطات
        edithex(libgcloud + oxorany(0x41727C), "FD 7B BE A9 1F 00 1F EB"); // غيابي  مربوطات

          
        
    
        
		close(handle);
			break;		
						
		}
	}
}

void FixGameCrash()
{
    system("rm -rf /data/data/pubgm.loader/files/ano_tmp");
    system("touch /data/data/pubgm.loader/files/ano_tmp");
    system("chmod 000 /data/data/pubgm.loader/files/ano_tmp");
    system("rm -rf /data/data/pubgm.loader/files/obblib");
    system("touch /data/data/pubgm.loader/files/obblib");
    system("chmod 000 /data/data/pubgm.loader/files/obblib");
    system("rm -rf /data/data/pubgm.loader/files/xlog");
    system("touch /data/data/pubgm.loader/files/xlog");
    system("chmod 000 /data/data/pubgm.loader/files/xlog");
    system("rm -rf /data/data/pubgm.loader/app_bugly");
    system("touch /data/data/pubgm.loader/app_bugly");
    system("chmod 000 /data/data/pubgm.loader/app_bugly");
    system("rm -rf /data/data/pubgm.loader/app_crashrecord");
    system("touch /data/data/pubgm.loader/app_crashrecord");
    system("chmod 000 /data/data/pubgm.loader/app_crashrecord");
    system("rm -rf /data/data/pubgm.loader/app_crashSight");
    system("touch /data/data/pubgm.loader/app_crashSight");
    system("chmod 000 /data/data/pubgm.loader/app_crashSight");
}
    


int getPID(const char *packageName) {
    char path[256];
    snprintf(path, sizeof(path), "/data/data/%s/files", packageName);
    
    DIR *dir = opendir(path);
    if (!dir) return 0; // Package folder not found

    closedir(dir);
    
    // Use system command to get PID
    char command[256];
    snprintf(command, sizeof(command), "pidof %s", packageName);
    FILE *fp = popen(command, "r");
    if (!fp) return 0;

    int pid = 0;
    fscanf(fp, "%d", &pid);
    pclose(fp);
    
    return pid;
}

void killProcess(const char *packageName) {
    int pid = getPID(packageName);
    if (pid > 0) {
        kill(pid, SIGKILL);
    }
}

int killGG() {
    DIR *dir = opendir("/data/data");
    if (!dir) return -1;

    struct dirent *ptr;
    while ((ptr = readdir(dir)) != NULL) {
        if (ptr->d_type != DT_DIR || strcmp(ptr->d_name, ".") == 0 || strcmp(ptr->d_name, "..") == 0)
            continue;

        char filepath[256];
        snprintf(filepath, sizeof(filepath), "/data/data/%s/files", ptr->d_name);
        
        DIR *dirGG = opendir(filepath);
        if (!dirGG) continue;

        struct dirent *ptrGG;
        while ((ptrGG = readdir(dirGG)) != NULL) {
            if (ptrGG->d_type != DT_DIR || strcmp(ptrGG->d_name, ".") == 0 || strcmp(ptrGG->d_name, "..") == 0)
                continue;

            if (strstr(ptrGG->d_name, "GG")) {
                killProcess(ptr->d_name);
            }
        }
        closedir(dirGG);
    }
    closedir(dir);
    return 0;
}
